﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using P320FrontToBack.Areas.AdminPanel.Data;
using P320Practise.Areas.AdminPanel.Data;
using P320Practise.DataAccessLayer;
using P320Practise.Models;
using P320Practise.ViewModels;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace P320Practise.Areas.AdminPanel.Controllers
{
    [Area("AdminPanel")]
    public class ProductController : Controller
    {
        private readonly AppDbContext _dbContext;

        public ProductController(AppDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<IActionResult> Index()
        {
            var products = await _dbContext.Products
                .Include(x => x.ProductImages)
                .Include(x => x.ProductCategories).ThenInclude(x => x.Category)
                .ToListAsync();

            return View(products);
        }

        public async Task<IActionResult> Create()
        {
            var parentCategories = await _dbContext.Categories
                .Where(x => x.IsDeleted == false && x.IsMain)
                .Include(x => x.Children.Where(y => y.IsDeleted == false))
                .ToListAsync();
            var childCategories = parentCategories[0].Children.ToList();
            ViewBag.ParentCategories = parentCategories;
            ViewBag.ChildCategories = childCategories;

            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Product product, int parentCategoryId, int? childCategoryId)
        {
            var parentCategories = await _dbContext.Categories
                .Where(x => x.IsDeleted == false && x.IsMain)
                .Include(x => x.Children.Where(y => y.IsDeleted == false))
                .ToListAsync();
            var childCategories = parentCategories[0].Children.ToList();
            ViewBag.ParentCategories = parentCategories;
            ViewBag.ChildCategories = childCategories;

            //var a = parentCategories.SelectMany(x => x.Children);

            if (!ModelState.IsValid)
                return View();

            var isProductExist = await _dbContext.Products
                .AnyAsync(x => x.Name.ToLower() == product.Name.ToLower());
            if (isProductExist)
            {
                ModelState.AddModelError("Name", "Bu product artiq movcuddur.");
                return View();
            }

            //var parentCategory = await _dbContext.Categories
            //    .Where(x => x.IsDeleted == false && x.Id == parentCategoryId)
            //    .Include(x => x.Children.Where(y => y.IsDeleted == false))
            //    .FirstOrDefaultAsync();
            var parentCategory = parentCategories.FirstOrDefault(x => x.Id == parentCategoryId);
            if (parentCategory == null)
                return BadRequest();

            if (childCategoryId != null)
            {
                //var isExistChildCategory =
                //    parentCategory.Children.All(x => x.Id != childCategoryId);
                //if (isExistChildCategory)
                //    return BadRequest();
                var isExistChildCategory =
                    parentCategory.Children.Any(x => x.Id == childCategoryId);
                if (!isExistChildCategory)
                    return BadRequest();
            }

            if (product.Photos == null || product.Photos.Length == 0)
            {
                ModelState.AddModelError("Photos", "Shekil yukleyin.");
                return View();
            }

            var productImages = new List<ProductImage>();

            foreach (var photo in product.Photos)
            {
                if (!photo.IsImage())
                {
                    ModelState.AddModelError("Photos", $"{photo.Name} Duzgun shekil formati sechin.");
                    return View();
                }

                if (!photo.IsAllowedSize(1))
                {
                    ModelState.AddModelError("Photos", $"{photo.Name} 1Mb-dan artiq ola bilmez.");
                    return View();
                }

                var fileName = await photo.GenerateFile(Constants.ImageFolderPath);

                var productImage = new ProductImage
                {
                    Name = fileName,
                    ProductId = product.Id
                };

                productImages.Add(productImage);
            }

            product.ProductImages = productImages;

            var productCategories = new List<ProductCategory>();

            var parentProductCategory = new ProductCategory
            {
                CategoryId = parentCategoryId,
                ProductId = product.Id
            };
            productCategories.Add(parentProductCategory);

            if (childCategoryId != null /*|| childCategoryId.HasValue*/)
            {
                //var a = childCategoryId.GetValueOrDefault();

                var childProductCategory = new ProductCategory
                {
                    //CategoryId = childCategoryId.Value,
                    CategoryId = (int)childCategoryId,
                    ProductId = product.Id
                };
                productCategories.Add(childProductCategory);
            }

            product.ProductCategories = productCategories;

            await _dbContext.Products.AddAsync(product);
            await _dbContext.SaveChangesAsync();

            return Content("Success");
        }

        public async Task<IActionResult> LoadChildren(int? parentCategoryId)
        {
            if (parentCategoryId == null)
                return BadRequest();

            var category = await _dbContext.Categories
                .Where(x => x.IsDeleted == false && x.IsMain && x.Id == parentCategoryId)
                .Include(x => x.Children.Where(y => y.IsDeleted == false))
                .FirstOrDefaultAsync();
            if (category == null)
                return NotFound();

            return PartialView("_ProductChildCategoriesPartial", category.Children.ToList());
        }

        public async Task<IActionResult> Update(int? id)
        {
            if (id == null)
                return NotFound();

            var product = await _dbContext.Products
                .Where(x => x.Id == id)
                .Include(x => x.ProductImages)
                .Include(x => x.ProductCategories).ThenInclude(x => x.Category)
                .FirstOrDefaultAsync();
            if (product == null)
                return NotFound();

            var parentCategories = await _dbContext.Categories
                .Where(x => x.IsDeleted == false && x.IsMain)
                .Include(x => x.Children.Where(y => y.IsDeleted == false))
                .ToListAsync();
            var childCategories = parentCategories[0].Children.ToList();

            var selectedParentCategoryId = product.ProductCategories
                .FirstOrDefault(x => x.Category.IsDeleted == false && x.Category.IsMain)
                .CategoryId;
            var selectedChildCategoryId = product.ProductCategories
                .FirstOrDefault(x => x.Category.IsDeleted == false && x.Category.IsMain == false)
                .CategoryId;

            var productViewModel = new ProductViewModel
            {
                Id = product.Id,
                Name = product.Name,
                Description = product.Description,
                Brand = product.Brand,
                Code = product.Code,
                ExTax = product.ExTax,
                Tags = product.Tags,
                Rate = product.Rate,
                Price = product.Price,
                DiscountPercent = product.DiscountPercent,
                ProductImages = product.ProductImages.ToList(),
                ParentCategories = parentCategories,
                SelectedParentCategoryId = selectedParentCategoryId,
                ChildCategories = childCategories,
                SelectedChildCategoryId = selectedChildCategoryId
            };

            return View(productViewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Update(int? id, ProductViewModel productViewModel)
        {
            if (id == null)
                return NotFound();

            if (id != productViewModel.Id)
                return BadRequest();

            var existProduct = await _dbContext.Products
                .Where(x => x.Id == id)
                .Include(x => x.ProductImages)
                .Include(x => x.ProductCategories).ThenInclude(x => x.Category)
                .FirstOrDefaultAsync();
            if (existProduct == null)
                return NotFound();

            var parentCategories = await _dbContext.Categories
                .Where(x => x.IsDeleted == false && x.IsMain)
                .Include(x => x.Children.Where(y => y.IsDeleted == false))
                .ToListAsync();
            var childCategories = parentCategories[0].Children.ToList();

            productViewModel.ParentCategories = parentCategories;
            productViewModel.ChildCategories = childCategories;
            productViewModel.ProductImages = existProduct.ProductImages.ToList();

            if (!ModelState.IsValid)
                return View(productViewModel);

            var isExistProduct = await _dbContext.Products
                .AnyAsync(x => x.Name == productViewModel.Name && x.Id != productViewModel.Id);
            if (isExistProduct)
            {
                ModelState.AddModelError("Name", "Bu adda mehsul movcuddur.");
                return View(productViewModel);
            }

            var existParentCategory = parentCategories
                .FirstOrDefault(x => x.IsDeleted == false && 
                                     x.IsMain && 
                                     x.Id == productViewModel.SelectedParentCategoryId);
            if (existParentCategory == null)
                return NotFound();

            if (productViewModel.SelectedChildCategoryId != null)
            {
                if (!existParentCategory.Children.Any(x => x.Id == productViewModel.SelectedChildCategoryId))
                    return NotFound();

                existProduct.ProductCategories
                    .FirstOrDefault(x => x.Category.IsDeleted == false && x.Category.IsMain == false)
                    .CategoryId = (int)productViewModel.SelectedChildCategoryId;
            }

            if (productViewModel.Photos != null && productViewModel.Photos.Length > 0)
            {
                foreach (var photo in productViewModel.Photos)
                {
                    if (!photo.IsImage())
                    {
                        ModelState.AddModelError("Photos", $"{photo.Name} Duzgun shekil formati sechin.");
                        return View();
                    }

                    if (!photo.IsAllowedSize(1))
                    {
                        ModelState.AddModelError("Photos", $"{photo.Name} 1Mb-dan artiq ola bilmez.");
                        return View();
                    }

                    var fileName = await photo.GenerateFile(Constants.ImageFolderPath);

                    var productImage = new ProductImage
                    {
                        Name = fileName,
                        ProductId = (int)id
                    };

                    await _dbContext.ProductImages.AddAsync(productImage);
                    await _dbContext.SaveChangesAsync();
                }
            }

            existProduct.Name = productViewModel.Name;
            existProduct.Description = productViewModel.Description;
            existProduct.Brand = productViewModel.Brand;
            existProduct.Code = productViewModel.Code;
            existProduct.ExTax = productViewModel.ExTax;
            existProduct.Tags = productViewModel.Tags;
            existProduct.Rate = productViewModel.Rate;
            existProduct.Price = productViewModel.Price;
            existProduct.DiscountPercent = productViewModel.DiscountPercent;

            existProduct.ProductCategories
                .FirstOrDefault(x => x.Category.IsDeleted == false && x.Category.IsMain)
                .CategoryId = productViewModel.SelectedParentCategoryId;

            await _dbContext.SaveChangesAsync();

            return RedirectToAction("Index");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteImage(int? id)
        {
            if (id == null)
                return NotFound();

            var productImage = await _dbContext.ProductImages.FindAsync(id);
            if (productImage == null)
                return NotFound();

            var count = await _dbContext.ProductImages
                .CountAsync(x => x.ProductId == productImage.ProductId);
            if (count == 1)
                return BadRequest();

            var path = Path.Combine(Constants.ImageFolderPath, productImage.Name);
            if (System.IO.File.Exists(path))
                System.IO.File.Delete(path);

            _dbContext.Remove(productImage);
            await _dbContext.SaveChangesAsync();

            return RedirectToAction(nameof(Update), new {id = productImage.ProductId});
        }
    }
}
